#include <Geode/Geode.hpp>
#include <Geode/loader/GameEvent.hpp>
#include <Geode/loader/SettingV3.hpp>

using namespace geode::prelude;

// Убивает игрока в обход noclip
static void killPlayer() {
    auto pl = PlayLayer::get();
    if (!pl || !pl->m_player1) return;

    // сначала обычный путь
    pl->destroyPlayer(pl->m_player1, nullptr);

    // если noclip заблокировал destroyPlayer — убиваем напрямую
    if (!pl->m_player1->m_isDead) {
        pl->m_player1->playerDestroyed(false);
        if (pl->m_player2) pl->m_player2->playerDestroyed(false);
        pl->delayedResetLevel();
    }
}

class KillWindow : public CCLayer {
protected:
    bool m_dragging = false;
    CCPoint m_grabOffset = {0, 0};
    CCSize m_size = {120.f, 60.f};
    float m_titleH = 16.f;

    bool init() override {
        if (!CCLayer::init()) return false;

        this->setContentSize(m_size);
        this->setAnchorPoint({0.f, 0.f});

        auto bg = CCLayerColor::create({20, 20, 20, 220}, m_size.width, m_size.height);
        this->addChild(bg);

        auto title = CCLayerColor::create({60, 60, 60, 255}, m_size.width, m_titleH);
        title->setPositionY(m_size.height - m_titleH);
        this->addChild(title);

        auto titleLabel = CCLabelBMFont::create("Kill Window", "bigFont.fnt");
        titleLabel->setScale(0.3f);
        titleLabel->setPosition({m_size.width / 2, m_size.height - m_titleH / 2});
        this->addChild(titleLabel);

        float bodyH = m_size.height - m_titleH;
        auto btn = CCLayerColor::create({200, 30, 30, 255}, m_size.width - 10, bodyH - 10);
        btn->setPosition({5, 5});
        this->addChild(btn);

        // иконка-череп вместо надписи
        if (auto skull = CCSprite::create("skull.png"_spr)) {
            skull->setScale((bodyH - 12.f) / skull->getContentSize().height);
            skull->setPosition({m_size.width / 2, bodyH / 2});
            this->addChild(skull);
        } else {
            auto label = CCLabelBMFont::create("DIE", "goldFont.fnt");
            label->setScale(0.6f);
            label->setPosition({m_size.width / 2, bodyH / 2});
            this->addChild(label);
        }

        this->setPosition({
            Mod::get()->getSavedValue<float>("pos-x", 60.f),
            Mod::get()->getSavedValue<float>("pos-y", 200.f)
        });
        this->setVisible(Mod::get()->getSettingValue<bool>("show-window"));

        this->setTouchEnabled(true);
        this->setZOrder(100000);
        return true;
    }

    void registerWithTouchDispatcher() override {
        CCTouchDispatcher::get()->addTargetedDelegate(this, -10000, true);
    }

    bool hit(CCTouch* touch) {
        auto p = this->convertToNodeSpace(touch->getLocation());
        return CCRect{0, 0, m_size.width, m_size.height}.containsPoint(p);
    }

    bool ccTouchBegan(CCTouch* touch, CCEvent*) override {
        // скрытое окно касания не ловит
        if (!this->isVisible() || !hit(touch)) return false;

        auto local = this->convertToNodeSpace(touch->getLocation());
        if (local.y >= m_size.height - m_titleH) {
            m_dragging = true;
            m_grabOffset = this->getPosition() - touch->getLocation();
        } else {
            killPlayer();
        }
        return true;
    }

    void ccTouchMoved(CCTouch* touch, CCEvent*) override {
        if (!m_dragging) return;
        auto win = CCDirector::get()->getWinSize();
        auto pos = touch->getLocation() + m_grabOffset;
        pos.x = std::clamp(pos.x, 0.f, win.width - m_size.width);
        pos.y = std::clamp(pos.y, 0.f, win.height - m_size.height);
        this->setPosition(pos);
    }

    void ccTouchEnded(CCTouch*, CCEvent*) override {
        if (m_dragging) {
            m_dragging = false;
            Mod::get()->setSavedValue("pos-x", this->getPositionX());
            Mod::get()->setSavedValue("pos-y", this->getPositionY());
        }
    }

    void ccTouchCancelled(CCTouch* t, CCEvent* e) override { ccTouchEnded(t, e); }

public:
    static inline KillWindow* instance = nullptr;

    static KillWindow* create() {
        auto ret = new KillWindow();
        if (ret && ret->init()) {
            ret->autorelease();
            return ret;
        }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }
};

$on_game(Loaded) {
    // окно живёт во всех сценах
    KillWindow::instance = KillWindow::create();
    SceneManager::get()->keepAcrossScenes(KillWindow::instance);

    // бинд на смерть (по умолчанию R, меняется в настройках мода)
    listenForKeybindSettingPresses("kill-key", [](Keybind const&, bool down, bool repeat, double) {
        if (down && !repeat) killPlayer();
    });

    // бинд на скрытие/показ окна (по умолчанию Ctrl+R)
    listenForKeybindSettingPresses("toggle-key", [](Keybind const&, bool down, bool repeat, double) {
        if (down && !repeat) {
            auto now = Mod::get()->getSettingValue<bool>("show-window");
            Mod::get()->setSettingValue<bool>("show-window", !now);
        }
    });

    // галочка в настройках скрывает/показывает окно
    listenForSettingChanges<bool>("show-window", [](bool value) {
        if (KillWindow::instance) KillWindow::instance->setVisible(value);
    });
}
